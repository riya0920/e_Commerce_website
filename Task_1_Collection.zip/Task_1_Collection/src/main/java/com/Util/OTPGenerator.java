package com.Util;

import com.Connection.EmployeeDao;

public class OTPGenerator {
	public static String generateOTP() {
		String alphaNum = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmonpqrstuvwxyz" + "0123456789";
		StringBuilder sb = new StringBuilder(6);
		for (int i=0;i<6;++i)
		{
			sb.append(alphaNum.charAt((int) (alphaNum.length() * Math.random())));
			
		}
		return sb.toString();
		
	}
}
