package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Products_Dao;

/**
 * Servlet implementation class AddToCartServlet
 */
public class AddToCartServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("In Servlet!!");
		String user = request.getParameter("user");
		request.setAttribute("user", user);
		System.out.println(user);
	Products_Dao pd= new Products_Dao();
	String u = pd.user_info(user);
	RequestDispatcher rd = null;
	if (u.equals("f")) {
		rd = request.getRequestDispatcher("UserInfo.jsp");
	}
	else
	{
		rd = request.getRequestDispatcher("BuyNow.jsp");
	}
	rd.forward(request, response);
	}
}
