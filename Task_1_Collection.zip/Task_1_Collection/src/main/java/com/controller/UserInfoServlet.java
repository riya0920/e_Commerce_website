	package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connection.EmployeeDao;
import com.Connection.Employeebean;

/**
 * Servlet implementation class UserInfoServlet
 */
public class UserInfoServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String address = request.getParameter("Address");
		String phone = request.getParameter("Phone");
		EmployeeDao ed = new EmployeeDao();
		HttpSession session=request.getSession();
		String user = (String) session.getAttribute("user");
		System.out.println(user);
		request.setAttribute("user", user);
		ed.adduserinfo(address,phone,user);
		RequestDispatcher rd = request.getRequestDispatcher("BuyNow.jsp");
		rd.forward(request, response);
	}
}
