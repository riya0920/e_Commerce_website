package com.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;
import java.util.Enumeration;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.EmployeeDao;
import com.Connection.Employeebean;
import com.Connection.EmployeebeanProducts;
import com.Connection.Products_Dao;
import com.Connection.Products_Display;
import com.mysql.cj.jdbc.Blob;

/**
 * Servlet implementation class Store_Collection
 */
public class SignupServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		EmployeeDao ed = new EmployeeDao();
		Products_Dao pd = new Products_Dao();
		

		
		String name = request.getParameter("fname");
		String email= request.getParameter("email");
		String uname= request.getParameter("uname");
		String pass= request.getParameter("pass");
		
		
		Employeebean eb = new Employeebean(name,email,uname,pass);
		int rows = ed.insert(eb);			
		
		RequestDispatcher rd = request.getRequestDispatcher("Login1.jsp");
		rd.forward(request, response);
//			
		
		}
	}



