package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.EmployeeDao;
import com.Util.OTPGenerator;
import com.Util.SendMail;

/**
 * Servlet implementation class ResetPassServlet
 */
public class ResetPassServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email  = request.getParameter("email");
		EmployeeDao ed = new EmployeeDao();
		if (ed.checkUser(email)>0) {
			String OTP = OTPGenerator.generateOTP();
			ed.storeOTP(email,OTP);
			SendMail.sendOtp(OTP,email);
			//Email Send
		}
		response.sendRedirect("NewPassword.jsp");
		
		
	}

}
