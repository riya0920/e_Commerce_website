package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Products_Dao;
import com.Connection.Products_Display;

/**
 * Servlet implementation class AddServlet
 */
public class AddServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id = request.getParameter("a_pid");
		String name = request.getParameter("a_name");
		String price = request.getParameter("a_price");
		String quantity = request.getParameter("a_quantity");
		int p = Integer.parseInt(price);
		int q = Integer.parseInt(quantity);
		Products_Dao pd = new Products_Dao();
		pd.Add(id, name, p, q);
		System.out.println("Heyyy");
		RequestDispatcher rd= request.getRequestDispatcher("SingleAdminProductsPage.jsp");
		rd.forward(request, response);
	}
}
