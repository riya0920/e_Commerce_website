package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Products_Dao;

/**
 * Servlet implementation class ProductsServlet
 */
public class ProductsServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ID = request.getParameter("id");
		String username = request.getParameter("user");
		request.setAttribute("User", username);
		Products_Dao pd = new Products_Dao();
		System.out.println(ID);
//		String username = (String)request.getAttribute("user");
		System.out.println(username);
		pd.cart(ID,username);
		RequestDispatcher rd = null;
		rd = request.getRequestDispatcher("AddToCart.jsp");
		rd.forward(request, response);
	}

}
