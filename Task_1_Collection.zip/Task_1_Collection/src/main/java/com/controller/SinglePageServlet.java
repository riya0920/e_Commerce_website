package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.EmployeeDao;
import com.Connection.Employeebean;
import com.Connection.EmployeebeanProducts;
import com.Connection.Products_Dao;
import com.Connection.Products_Display;

/**
 * Servlet implementation class SinglePageServlet
 */
public class SinglePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    ServletConfig cfg ;
    public void init(ServletConfig config) throws ServletException 
    {
    	cfg = config;
//    	initparams =  cfg.getInitParameterNames();
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		Products_Dao ed = new Products_Dao();
		String p_uid = request.getParameter("p_uid");
		String p_pass = request.getParameter("p_pass");		
//		System.out.println(p_pass + p_uid);
		String err = "";
		boolean flag = false;
		RequestDispatcher rd = null;
		
		String a_uid = cfg.getInitParameter("user");
		String a_pass = cfg.getInitParameter("pass");
		if(p_uid.equals(a_uid) && p_pass.equals(a_pass))
		{
//			System.out.println("in if");
			doPost(request, response);
			
		}
		else
		{
			err = "Incorrect";
			rd = request.getRequestDispatcher("SingleAdminPage.jsp");
			request.setAttribute("err", err);
			rd.forward(request, response);
		}
		// TODO Auto-generated method stub
//		super.doGet(req, resp);
	}
//	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		EmployeebeanProducts ebp = new EmployeebeanProducts();
		Products_Dao ed = new Products_Dao();
//		PrintWriter out = response.getWriter();
		ArrayList<String> list = new ArrayList<String>();
				ed.retrivePRODUCTID(ebp);
		String list_name = ed.retrivePRODUCTNAME(ebp);
		String list_Price = ed.retrivePRODUCTPrice(ebp);
		String list_Quantity = ed.retrivePRODUCTQuantity(ebp);
//		System.out.println(list_ID + " " + list_name + " " + list_Price + " " + list_Quantity);
		request.setAttribute("ID", list_ID);
		request.setAttribute("name", list_name);
		request.setAttribute("Price", list_Price);
		request.setAttribute("Quantity", list_Quantity);
//		System.out.println("End of post");
		RequestDispatcher rd = request.getRequestDispatcher("SingleAdminProductsPage.jsp");
		rd.forward(request, response);
//		out.print(list);
//		System.out.println("Moreend");
//		System.out.println(list_ID);
	}

}


