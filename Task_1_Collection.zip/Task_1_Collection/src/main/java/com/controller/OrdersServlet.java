package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Products_Dao;

/**
 * Servlet implementation class OrdersServlet
 */
public class OrdersServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String user = request.getParameter("user");
		Products_Dao pd = new Products_Dao();
		String order = pd.getOrders(user);
		request.setAttribute("user", user);
		request.setAttribute("orders", order);
		RequestDispatcher rd = request.getRequestDispatcher("Orders.jsp");
		rd.forward(request, response);
	}

}
