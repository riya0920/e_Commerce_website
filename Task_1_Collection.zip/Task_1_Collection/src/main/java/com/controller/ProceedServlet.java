package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.Products_Dao;

/**
 * Servlet implementation class ProceedServlet
 */
public class ProceedServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("user");
		Products_Dao pd = new Products_Dao();
		pd.orders(username);
		RequestDispatcher rd = request.getRequestDispatcher("ThankYou.jsp");
		rd.forward(request, response);
	}
}
