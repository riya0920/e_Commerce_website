package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connection.EmployeeDao;
import com.Connection.Employeebean;
import com.Connection.EmployeebeanProducts;
import com.Connection.Products_Dao;
import com.Connection.Products_Display;

public class LoginServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		EmployeeDao ed = new EmployeeDao();
		Products_Dao pd = new Products_Dao();
		Employeebean eb = new Employeebean();
		
		String uid= request.getParameter("uid");
		String password= request.getParameter("password");
		
		int disp = ed.retrive(uid, eb, password);
		String e = "";
		
		RequestDispatcher rd = null;
		
		if (disp == 0) {
			e = "No such username";
			rd = request.getRequestDispatcher("Login1.jsp");
			
			request.setAttribute("error", e);
			rd.forward(request, response);
		}
		
		else
		{
			request.setAttribute("UserName", uid);
			rd = request.getRequestDispatcher("Products.jsp");
			rd.forward(request, response);
		}
	}

}
