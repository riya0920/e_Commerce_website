package com.Listener;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class RequestListener implements ServletRequestListener{

	public static int count = 0;
	public void requestDestroyed(ServletRequestEvent arg0) {
		// TODO Auto-generated method stub
		--count;
		
	}

	@Override
	public void requestInitialized(ServletRequestEvent arg0) {
	++count;
	System.out.println("Number of users logged in: " + count);
		
	}

}
