package com.Headers;
import java.util.Date;

public class Greeting {

	public static String Greet()
	{
		Date d = new Date();
		if (d.getHours()> 6 && d.getHours()<12) {
			return "Good Morning!";
		}
		else if (d.getHours()>12 && d.getHours()<20) {
			return "Good Evening";
		}
		else
		{
			return "Good Night";
		}
		
	}
}
