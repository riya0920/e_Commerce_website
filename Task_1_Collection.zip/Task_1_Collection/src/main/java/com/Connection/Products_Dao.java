package com.Connection;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.Blob;

public class Products_Dao {

	public void cart(String ID, String user) {
		
		
		String dispQ = "UPDATE PRODUCTS SET Quantity = Quantity-1 WHERE PRODUCT_ID=" + "'"+ID+"';";
		String dispQ1 = "UPDATE EMPLOYEES SET ADD_TO_CART = CONCAT(ADD_TO_CART, "+ "'"+ID+" ') WHERE USERNAME = '" + user + "';";
		System.out.println(dispQ);
		System.out.println(dispQ1);
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				int rows = stmt.executeUpdate(dispQ);
				System.out.println(rows);
				int row = stmt.executeUpdate(dispQ1);
				System.out.println(rows);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void orders(String user)
	{
//		String dispQ = "UPDATE PRODUCTS SET Quantity = Quantity-1 WHERE PRODUCT_ID=" + "'"+ID+"';";
		String dispQ = "UPDATE EMPLOYEES SET ORDERS = ADD_TO_CART, ADD_TO_CART = ' ' WHERE USERNAME = '" + user + "';";
//		String dispQ1 = "UPDATE EMPLOYEES SET ADD_TO_CART = CONCAT(ADD_TO_CART, "+ "'"+ID+" ') WHERE USERNAME = '" + user + "';";
		System.out.println(dispQ);
//		System.out.println(dispQ1);
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				int rows = stmt.executeUpdate(dispQ);
				System.out.println(rows);
//				int row = stmt.executeUpdate(dispQ1);
//				System.out.println(rows);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public String user_info(String user)
	{
		String dispQ = "SELECT ADDRESS,PHONE FROM EMPLOYEES WHERE USERNAME = '"+user+"';";
		System.out.println(dispQ);
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				while(rs.next())
				{
					String check = rs.getString(1);
					if (check == null)
					{
						return "f";
					}
					else {
						return "t";
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return "ft";
	}
	public String retrivePRODUCTID (EmployeebeanProducts ebp) {
		// TODO Auto-generated method stub
		String dispQ = "SELECT * FROM PRODUCTS";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String list = "";
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				
				while (rs.next()) {
						list = list+rs.getString(1);
						list = list + "         ";
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println(list);
		System.out.println("IN retrive!");
		return list;
	}
	public String retrivePRODUCTNAME (EmployeebeanProducts ebp) {
		// TODO Auto-generated method stub
		String dispQ = "SELECT * FROM PRODUCTS";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String list = "";
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				
				while (rs.next()) {
						list = list + rs.getString(3);
						list = list + "         ";
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println(list);
		System.out.println("IN retrive!");
		return list;
	}
	public String retrivePRODUCTPrice (EmployeebeanProducts ebp) {
		// TODO Auto-generated method stub
		String dispQ = "SELECT * FROM PRODUCTS";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String list = "";
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				
				while (rs.next()) {
						list = list + rs.getString(4);
						list = list +"         ";
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println(list);
		System.out.println("IN retrive!");
		return list;
	}
	public String retrivePRODUCTQuantity (EmployeebeanProducts ebp) {
		// TODO Auto-generated method stub
		String dispQ = "SELECT * FROM PRODUCTS";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String list = "";
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				
				while (rs.next()) {
					list = list + rs.getString(5);
					list = list + "         ";
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println(list);
		System.out.println("IN retrive!");
		return list;
	}
	public void Modify(String id,String field,String value)
	{
		String dispQ;
		if (field.equals("Price") || field.equals("Quantity"))
		{
			int val = Integer.parseInt(value);
			dispQ = "UPDATE PRODUCTS SET "+field + " = " + val + " WHERE PRODUCT_ID = " + "'"+ id+"'";
		}
		else
		{
			String val = value;
			dispQ = "UPDATE PRODUCTS SET "+field + " = " + "'" + val + "'" + " WHERE PRODUCT_ID = " + "'"+ id+"'";
		}
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				int rows = stmt.executeUpdate(dispQ);
				System.out.println(rows);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//		return rows;
	}	
	}
	public void Add(String a_pid, String a_name, int a_price, int a_quantity) {
		// TODO Auto-generated method stub
		String dispQ = "INSERT INTO PRODUCTS (PRODUCT_ID,NAME,PRICE,QUANTITY) VALUES ('" + a_pid +"','"+ a_name +"'," + a_price + "," + a_quantity + ");";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				int rows = stmt.executeUpdate(dispQ);
				System.out.println(rows);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}	
	}
	public void Delete(String r_pid) {
		// TODO Auto-generated method stub
		String dispQ = "DELETE FROM PRODUCTS WHERE PRODUCT_ID = '" + r_pid+ "';" ;
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				int rows = stmt.executeUpdate(dispQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}	
	}
	public String getOrders(String user) {
		
		String dispQ = "SELECT * FROM EMPLOYEES WHERE USERNAME = '" +user+"';" ;
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String list = " ";
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				
				while (rs.next()) {
					list = list + rs.getString(8);
					list = list + " ";
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
		return list;
	

}
	}
