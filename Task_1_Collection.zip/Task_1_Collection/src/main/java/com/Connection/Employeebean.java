package com.Connection;


public class Employeebean
{
	public String fnmae;
	public String email;
	public String username;
	public String pass;
	public String address;
	public String phone;
	
	public Employeebean(String fnmae, String email, String username, String pass) {
//		super();
		this.fnmae = fnmae;
		this.email = email;
		this.username = username;
		this.pass = pass;
	}

	public Employeebean() {
		// TODO Auto-generated constructor stub
	}

	public Employeebean(String address, String phone) {
		this.address = address;
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFnmae() {
		return fnmae;
	}


	public void setFnmae(String fnmae) {
		this.fnmae = fnmae;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getEmail() {
		return email;
	}


	public String getUsername() {
		return username;
	}


	public String getPass() {
		return pass;
	}


	

}