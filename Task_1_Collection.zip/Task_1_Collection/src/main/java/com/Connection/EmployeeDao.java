package com.Connection;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.jdbc.Blob;

public class EmployeeDao{

	public int insert(Employeebean eb) {
		// TODO Auto-generated method stub
		String insertQ = "INSERT INTO EMPLOYEES (FIRSTNAME,EMAIL,USERNAME,PASSWORD,ADD_TO_CART,ORDERS) VALUES ('"+eb.getFnmae()+"','"+eb.getEmail()+"','"+eb.getUsername()+"','"+eb.getPass()+"',' ',' ')";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				rows = stmt.executeUpdate(insertQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN INSERT!");
		System.out.println(rows);
		return rows;
	}
	
	public int retrive(String uid,Employeebean eb,String pass) {
		// TODO Auto-generated method stub
		String dispQ = "SELECT * FROM EMPLOYEES WHERE USERNAME = "+ "'"+uid+"'" + "AND PASSWORD = "+"'"+pass+"'";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
//		List<Employeebean> list = new ArrayList<Employeebean>();
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				while (rs.next()) {
	                
	                /*Retrieve one employee details 
	                and store it in employee object*/
	                eb.setFnmae(rs.getString("FIRSTNAME"));
	                eb.setEmail(rs.getString("EMAIL"));
	                eb.setUsername(rs.getString("USERNAME"));
	                eb.setPass(rs.getString("PASSWORD"));
	                ++rows;
	                //add each employee to the list
//	                list.add(eb);
				
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN retrive!");
		return rows;
	}
	
	
	public Blob retrivePRODUCT () {
		// TODO Auto-generated method stub
		String dispQ = "SELECT * FROM PRODUCTS";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
//		List<Employeebean> list = new ArrayList<Employeebean>();
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(dispQ);
				while (rs.next()) {
	                
	                /*Retrieve one employee details 
	                and store it in employee object*/
//	                eb.setFnmae(rs.getString("PRODUCT_ID"));
					try {
//						java.sql.Blob imageBlob = rs.getBlob("IMAGE");
//						InputStream binaryStream = imageBlob.getBinaryStream(0, imageBlob.length());
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
//	                System.out.print(rs.getBlob("IMAGE"));
//	                eb.setUsername(rs.getString("USERNAME"));
//	                eb.setPass(rs.getString("PASSWORD"));
	                ++rows;
	                //add each employee to the list
//	                list.add(eb);
				
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN retrive!");
//		return rows;
		return null;
	}

	public void adduserinfo(String add,String phone, String user) {

		String insertQ = "UPDATE EMPLOYEES SET ADDRESS = '"+add+"',PHONE = '"+phone+"' WHERE USERNAME = '" + user + "';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				rows = stmt.executeUpdate(insertQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN INSERT ADDRESS!");
		System.out.println(rows);
	}

	public Integer checkUser(String email) {
		String query = "SELECT * FROM EMPLOYEES WHERE EMAIL = '" +email +"';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				while (rs.next()) {
	                 ++rows;				
					}
				}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN checkUser!");
		// TODO Auto-generated method stub
		return rows;
		
	}

	public void storeOTP(String email, String oTP) {
		String insertQ = "UPDATE EMPLOYEES SET OTP = '"+oTP+"' WHERE EMAIL = '" + email + "';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				rows = stmt.executeUpdate(insertQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN update OTP!");
		System.out.println(rows);
	}

	public void checkOTP(String email, String OTP,String pass) {
		// TODO Auto-generated method stub
		String query = "SELECT * FROM EMPLOYEES WHERE EMAIL = '" +email +"';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		String otp = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				while (rs.next()) {
	                otp = rs.getString("OTP");				
					}
				}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		if (otp.equals(OTP)) {
			EmployeeDao ed = new EmployeeDao();
			ed.addnewP(pass,email);
		}
		System.out.println("IN checkOTP!");
		// TODO Auto-generated method stub
	}

	private void addnewP(String pass, String email) {
		String insertQ = "UPDATE EMPLOYEES SET password = '"+pass+"' WHERE EMAIL = '" + email + "';";
		Connection conn = DbConnection.getDbConnection();
		Statement stmt = null;
		int rows = 0;
		if (conn != null)
		{
			try {
				stmt = conn.createStatement();
				rows = stmt.executeUpdate(insertQ);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println("IN update pass!");
		System.out.println(rows);
	}
	
	
	
}